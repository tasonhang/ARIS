"use client"

import { useRef, useCallback, useState, useEffect } from "react"
import { useApex } from "@/contexts/apex-context"

interface UseVoiceOptions {
  wakeWord?: string
  onCommand?: (command: string) => void
}

export function useVoice({ wakeWord = "wake up", onCommand }: UseVoiceOptions = {}) {
  const { state, setState, setLastCommand, setLastResponse } = useApex()
  const recognitionRef = useRef<SpeechRecognition | null>(null)
  const audioContextRef = useRef<AudioContext | null>(null)
  const [isListening, setIsListening] = useState(false)
  const [hasPermission, setHasPermission] = useState(false)
  const [isSupported, setIsSupported] = useState(false)
  const [isSafariMobile, setIsSafariMobile] = useState(false)
  const isListeningForCommandRef = useRef(false)
  const restartTimeoutRef = useRef<NodeJS.Timeout | null>(null)
  const isSpeakingRef = useRef(false)
  
  // Check browser capabilities on mount (client-side only)
  useEffect(() => {
    const hasSpeechRecognition = !!(window.SpeechRecognition || window.webkitSpeechRecognition)
    setIsSupported(hasSpeechRecognition)
    
    // Detect Safari iOS
    const ua = navigator.userAgent
    const isIOS = /iPad|iPhone|iPod/.test(ua) || (navigator.platform === "MacIntel" && navigator.maxTouchPoints > 1)
    const isSafari = /^((?!chrome|android).)*safari/i.test(ua)
    setIsSafariMobile(isIOS && isSafari)
  }, [])
  
  const speak = useCallback((text: string) => {
    setState("speaking")
    setLastResponse(text)
    isSpeakingRef.current = true
    
    if (typeof window === "undefined") {
      setTimeout(() => {
        setState("idle")
        isSpeakingRef.current = false
      }, 1000)
      return
    }
    
    // Stop recognition while speaking
    if (recognitionRef.current) {
      try {
        recognitionRef.current.stop()
      } catch {
        // Already stopped
      }
    }
    
    // Call ElevenLabs TTS API
    fetch("/api/voice/speak", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({ text }),
    })
      .then((response) => {
        if (!response.ok) throw new Error("TTS request failed")
        return response.arrayBuffer()
      })
      .then((audioBuffer) => {
        // Initialize AudioContext if needed
        if (!audioContextRef.current) {
          audioContextRef.current = new (window.AudioContext || (window as any).webkitAudioContext)()
        }

        const audioContext = audioContextRef.current
        audioContext.decodeAudioData(audioBuffer, (decodedData) => {
          const source = audioContext.createBufferSource()
          source.buffer = decodedData
          source.connect(audioContext.destination)
          
          source.onended = () => {
            setState("idle")
            isSpeakingRef.current = false
            // Restart recognition after speaking if we were listening
            if (isListening && recognitionRef.current) {
              setTimeout(() => {
                try {
                  recognitionRef.current?.start()
                } catch {
                  // Already started or error
                }
              }, 200)
            }
          }
          
          source.start(0)
        })
      })
      .catch((error) => {
        console.error("TTS error:", error)
        setState("idle")
        isSpeakingRef.current = false
      })
  }, [setState, setLastResponse, isListening])
  
  const processCommand = useCallback((command: string) => {
    const lowerCommand = command.toLowerCase()
    
    if (onCommand) {
      onCommand(command)
    }
    
    if (lowerCommand.includes("lead") || lowerCommand.includes("leads")) {
      speak("You have 12 active leads. The most recent is John Smith, who inquired about a property in downtown.")
    } else if (lowerCommand.includes("schedule") || lowerCommand.includes("calendar") || lowerCommand.includes("appointment")) {
      speak("You have 3 appointments today. The next one is at 2 PM with Sarah Johnson for a property viewing.")
    } else if (lowerCommand.includes("message") || lowerCommand.includes("messages")) {
      speak("You have 5 unread messages. Would you like me to read them?")
    } else if (lowerCommand.includes("property") || lowerCommand.includes("properties") || lowerCommand.includes("listing")) {
      speak("You have 8 active listings. The most viewed property is the 3 bedroom house on Oak Street.")
    } else if (lowerCommand.includes("deal") || lowerCommand.includes("deals")) {
      speak("You have 4 deals in progress. 2 are pending closing this week.")
    } else if (lowerCommand.includes("help")) {
      speak("I can help you with leads, schedules, messages, properties, and deals. Just say wake up and then your command.")
    } else if (lowerCommand.includes("hello") || lowerCommand.includes("hi")) {
      speak("Hello! How can I assist you today?")
    } else if (lowerCommand.includes("thank")) {
      speak("You're welcome! Is there anything else I can help with?")
    } else {
      speak(`I heard: ${command}. This feature will be available soon.`)
    }
  }, [speak, onCommand])
  
  // Initialize recognition - called on user gesture (mic button tap)
  const initializeRecognition = useCallback(() => {
    if (typeof window === "undefined") return null
    
    // Use webkitSpeechRecognition for Safari
    const SpeechRecognitionAPI = window.webkitSpeechRecognition || window.SpeechRecognition
    if (!SpeechRecognitionAPI) return null
    
    const recognition = new SpeechRecognitionAPI()
    
    // Use continuous: false and manually restart after each result
    // This fixes the PWA mode restart failure
    recognition.continuous = false
    recognition.interimResults = false
    
    recognition.lang = "en-US"
    recognition.maxAlternatives = 1
    
    recognition.onresult = (event: SpeechRecognitionEvent) => {
      const lastResult = event.results[event.results.length - 1]
      
      if (!lastResult.isFinal) return
      
      const transcript = lastResult[0].transcript.toLowerCase().trim()
      
      if (!isListeningForCommandRef.current) {
        if (transcript.includes(wakeWord.toLowerCase())) {
          isListeningForCommandRef.current = true
          setState("listening")
          speak("Yes, I'm listening")
        }
      } else {
        isListeningForCommandRef.current = false
        setLastCommand(transcript)
        processCommand(transcript)
      }
    }
    
    recognition.onerror = (event: SpeechRecognitionErrorEvent) => {
      // Silently handle errors - no error messages shown
      console.debug("Speech recognition error:", event.error)
    }
    
    recognition.onend = () => {
      // Auto-restart for continuous listening (ARIA should never stop listening unless manually turned off)
      if (isListening && state !== "speaking" && !isSpeakingRef.current) {
        // Clear any pending restart timeout
        if (restartTimeoutRef.current) {
          clearTimeout(restartTimeoutRef.current)
        }
        
        // Retry restart after 500ms to handle PWA mode failures
        restartTimeoutRef.current = setTimeout(() => {
          try {
            if (recognitionRef.current && isListening) {
              recognitionRef.current.start()
            }
          } catch (error) {
            console.debug("Voice listener restart error (retrying):", error)
            // If restart fails, retry again after 500ms
            if (restartTimeoutRef.current) {
              clearTimeout(restartTimeoutRef.current)
            }
            restartTimeoutRef.current = setTimeout(() => {
              try {
                if (recognitionRef.current && isListening) {
                  recognitionRef.current.start()
                }
              } catch (e) {
                console.debug("Voice listener restart retry failed:", e)
              }
            }, 500)
          }
        }, 500)
      }
    }
    
    return recognition
  }, [wakeWord, setState, setLastCommand, processCommand, speak, isListening, state])
  
  // Start listening - triggered by mic button tap (user gesture)
  const startListening = useCallback(async () => {
    if (!isSupported) return
    
    // Step 1: Request microphone permission via getUserMedia FIRST
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true })
      stream.getTracks().forEach(track => track.stop())
      setHasPermission(true)
    } catch {
      // Permission denied - but don't show error, just fail silently
      return
    }
    
    // Step 2: Initialize speech recognition after permission granted
    if (!recognitionRef.current) {
      recognitionRef.current = initializeRecognition()
    }
    
    if (!recognitionRef.current) return
    
    // Step 3: Start recognition
    try {
      recognitionRef.current.start()
      setIsListening(true)
      setState("idle") // Ready to hear wake word
    } catch (error) {
      console.debug("Recognition start error:", error)
      // May already be started
    }
  }, [isSupported, initializeRecognition, setState])
  
  // Stop listening
  const stopListening = useCallback(() => {
    // Clear any pending restart timeout
    if (restartTimeoutRef.current) {
      clearTimeout(restartTimeoutRef.current)
    }
    
    if (recognitionRef.current) {
      try {
        recognitionRef.current.stop()
      } catch {
        // Already stopped
      }
    }
    setIsListening(false)
    isListeningForCommandRef.current = false
    setState("idle")
  }, [setState])
  
  // Cleanup on unmount
  useEffect(() => {
    return () => {
      if (restartTimeoutRef.current) {
        clearTimeout(restartTimeoutRef.current)
      }
      stopListening()
    }
  }, [stopListening])
  
  // Manual command via text input
  const manualCommand = useCallback((command: string) => {
    setLastCommand(command)
    processCommand(command)
  }, [setLastCommand, processCommand])
  
  return {
    isSupported,
    isSafariMobile,
    isListening,
    hasPermission,
    state,
    startListening,
    stopListening,
    speak,
    manualCommand,
  }
}

// Type declarations for Web Speech API
declare global {
  interface Window {
    SpeechRecognition: typeof SpeechRecognition
    webkitSpeechRecognition: typeof SpeechRecognition
    AudioContext: typeof AudioContext
    webkitAudioContext: typeof AudioContext
  }
}
